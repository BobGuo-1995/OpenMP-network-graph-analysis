#include <iostream>
#include <sys/time.h>
#include <cstdlib>
#include <omp.h>
using namespace std;

/* ------------------------------------------------------------- */
/* Various timing functions and variables                        */
struct timeval start_time ;
struct timeval finish_time ;
struct timeval current_time ;

void tic() {
   gettimeofday( &start_time, NULL ) ;    
}

void toc() {
   gettimeofday( &finish_time, NULL ) ;    
}


double etime( ) {
   
   long esec, eusec ;
   double r ;

   esec = finish_time.tv_sec - start_time.tv_sec ;
   eusec = finish_time.tv_usec - start_time.tv_usec ;

   r = ((double) esec) + ((double) eusec) / 1000000.0 ;
   return r ;
}
/* ------------------------------------------------------------- */

int main(int argc, char* argv[]) {
	if (argc != 4) {
		cout << "Usage: ./network input_file output_file number_of_threads" << endl;
		exit(-1);
	}

	return 0;
}

